Full redacted transcripts of the tool evaluation (results/tool_eval/).
minimal/: the study behind the paper's table (minimal/cases.json, minimal/results.csv).
  minimal/<run>/full.log: the complete transcript of one row of minimal/results.csv.
  minimal/<run>/csynth.xml: its csynth report, when it synthesized.
  minimal/<run>/synth-unchecked.log and synth-unchecked-csynth.xml: Vitis on output that failed the
    functional check (minimal/synth_unchecked.csv).
build-*.log: tool builds, including failed setup attempts as well as verified builds.
control-*.log: each tool on its own upstream example (control-autosa.log is the row
  autosa_control_mm/autosa of minimal/results.csv).
setup-tests/: test runs of the control wrappers while they were written, and the regeneration check.
environment-probe.log: the machine and tool environment.
No compiler build trees, vendor headers, licenses, credentials, or raw private logs are included.
