Full redacted transcripts of the tool evaluation (results/tool_eval/).
tool_run_log/: every tool run of the study behind the paper's table (tool_run_log/cases.json,
  tool_run_log/results.csv in the repository).
  tool_run_log/<run>/full.log: the complete transcript of one row of tool_run_log/results.csv.
  tool_run_log/<run>/csynth.xml: its csynth report, when it synthesized.
  tool_run_log/<run>/synth-unchecked.log and synth-unchecked-csynth.xml: Vitis on output that failed the
    functional check (tool_run_log/synth_unchecked.csv).
build-*.log: tool builds, including failed setup attempts as well as verified builds.
control-*.log: each tool on its own upstream example (control-autosa.log is the row
  autosa_control_mm/autosa of tool_run_log/results.csv).
setup-tests/: test runs of the control wrappers while they were written, and the regeneration check.
environment-probe.log: the machine and tool environment.
No compiler build trees, vendor headers, licenses, credentials, or raw private logs are included.
