Full redacted transcripts for the fresh tool-evaluation evidence package.
fresh/: unchanged benchmark runs and original Vitis baselines.
historical/: recovered older AutoSA transcripts, not fresh measurements.
diagnostic/: explicitly edited/header-mode experiments.
excluded-setup/: missing-header or wrong-function-selector attempts; NOT benchmark outcomes.
minimal/: the minimal-edit study (whole designs and single operators; see minimal/cases.json).
  minimal/<run>/full.log: the complete transcript of one row of minimal/results.csv.
  minimal/<run>/csynth.xml: its csynth report, when it synthesized.
  minimal/<run>/synth-unchecked.log and synth-unchecked-csynth.xml: Vitis on output that failed the
    functional check (minimal/synth_unchecked.csv).
setup-tests/: test runs of the control wrappers while they were written, and the regeneration check.
build*.log: includes failed setup attempts as well as verified builds.
No compiler build trees, vendor headers, licenses, credentials, or raw private logs are included.
