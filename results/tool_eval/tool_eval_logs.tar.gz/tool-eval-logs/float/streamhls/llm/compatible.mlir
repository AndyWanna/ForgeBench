module attributes {dlti.dl_spec = #dlti.dl_spec<#dlti.dl_entry<f80, dense<128> : vector<2xi64>>, #dlti.dl_entry<!llvm.ptr, dense<64> : vector<4xi64>>, #dlti.dl_entry<i1, dense<8> : vector<2xi64>>, #dlti.dl_entry<i8, dense<8> : vector<2xi64>>, #dlti.dl_entry<i16, dense<16> : vector<2xi64>>, #dlti.dl_entry<i32, dense<32> : vector<2xi64>>, #dlti.dl_entry<f64, dense<64> : vector<2xi64>>, #dlti.dl_entry<f128, dense<128> : vector<2xi64>>, #dlti.dl_entry<f16, dense<16> : vector<2xi64>>, #dlti.dl_entry<!llvm.ptr<270>, dense<32> : vector<4xi64>>, #dlti.dl_entry<!llvm.ptr<271>, dense<32> : vector<4xi64>>, #dlti.dl_entry<!llvm.ptr<272>, dense<64> : vector<4xi64>>, #dlti.dl_entry<i64, dense<64> : vector<2xi64>>, #dlti.dl_entry<"dlti.stack_alignment", 128 : i64>, #dlti.dl_entry<"dlti.endianness", "little">>, llvm.data_layout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128", llvm.target_triple = "x86_64-unknown-linux-gnu", "polygeist.target-cpu" = "x86-64", "polygeist.target-features" = "+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87", "polygeist.tune-cpu" = "generic"} {
  memref.global @BRAM_norm_output : memref<8x128xf32> = uninitialized
  memref.global @BRAM_norm_beta : memref<128xf32> = uninitialized
  memref.global @BRAM_norm_gamma : memref<128xf32> = uninitialized
  memref.global @BRAM_attn_output : memref<8x128xf32> = uninitialized
  memref.global @BRAM_WV : memref<128x128xf32> = uninitialized
  memref.global @BRAM_WK : memref<128x128xf32> = uninitialized
  memref.global @BRAM_WQ : memref<128x128xf32> = uninitialized
  memref.global @BRAM_attn_input : memref<8x128xf32> = uninitialized
  func.func @_Z3topPA128_fS0_S0_S0_S0_PfS1_(%arg0: memref<8x128xf32>, %arg1: memref<128x128xf32>, %arg2: memref<128x128xf32>, %arg3: memref<128x128xf32>, %arg4: memref<8x128xf32>, %arg5: memref<128xf32>, %arg6: memref<128xf32>) attributes {llvm.linkage = #llvm.linkage<external>} {
    %cst = arith.constant 1.280000e+02 : f32
    %cst_0 = arith.constant 0.00999999977 : f32
    %cst_1 = arith.constant 2.500000e-01 : f32
    %cst_2 = arith.constant 0.000000e+00 : f32
    %cst_3 = arith.constant 1.000000e+04 : f32
    %cst_4 = arith.constant 1.600000e+01 : f32
    %0 = memref.get_global @BRAM_attn_input : memref<8x128xf32>
    affine.for %arg7 = 0 to 8 {
      affine.for %arg8 = 0 to 128 {
        %8 = affine.load %arg0[%arg7, %arg8] : memref<8x128xf32>
        affine.store %8, %0[%arg7, %arg8] : memref<8x128xf32>
      }
    }
    %1 = memref.get_global @BRAM_WQ : memref<128x128xf32>
    affine.for %arg7 = 0 to 128 {
      affine.for %arg8 = 0 to 128 {
        %8 = affine.load %arg1[%arg7, %arg8] : memref<128x128xf32>
        affine.store %8, %1[%arg7, %arg8] : memref<128x128xf32>
      }
    }
    %2 = memref.get_global @BRAM_WK : memref<128x128xf32>
    affine.for %arg7 = 0 to 128 {
      affine.for %arg8 = 0 to 128 {
        %8 = affine.load %arg2[%arg7, %arg8] : memref<128x128xf32>
        affine.store %8, %2[%arg7, %arg8] : memref<128x128xf32>
      }
    }
    %3 = memref.get_global @BRAM_WV : memref<128x128xf32>
    affine.for %arg7 = 0 to 128 {
      affine.for %arg8 = 0 to 128 {
        %8 = affine.load %arg3[%arg7, %arg8] : memref<128x128xf32>
        affine.store %8, %3[%arg7, %arg8] : memref<128x128xf32>
      }
    }
    %4 = memref.get_global @BRAM_attn_output : memref<8x128xf32>
    %alloca = memref.alloca() : memref<8x8xf32>
    %alloca_5 = memref.alloca() : memref<8x128xf32>
    %alloca_6 = memref.alloca() : memref<8x128xf32>
    %alloca_7 = memref.alloca() : memref<8x128xf32>
    affine.for %arg7 = 0 to 8 {
      affine.for %arg8 = 0 to 128 {
        affine.store %cst_2, %alloca_7[%arg7, %arg8] : memref<8x128xf32>
        affine.store %cst_2, %alloca_6[%arg7, %arg8] : memref<8x128xf32>
        affine.store %cst_2, %alloca_5[%arg7, %arg8] : memref<8x128xf32>
        %8:3 = affine.for %arg9 = 0 to 128 iter_args(%arg10 = %cst_2, %arg11 = %cst_2, %arg12 = %cst_2) -> (f32, f32, f32) {
          %9 = affine.load %0[%arg7, %arg9] : memref<8x128xf32>
          %10 = affine.load %1[%arg8, %arg9] : memref<128x128xf32>
          %11 = arith.mulf %9, %10 : f32
          %12 = arith.addf %arg12, %11 : f32
          affine.store %12, %alloca_7[%arg7, %arg8] : memref<8x128xf32>
          %13 = affine.load %0[%arg7, %arg9] : memref<8x128xf32>
          %14 = affine.load %2[%arg8, %arg9] : memref<128x128xf32>
          %15 = arith.mulf %13, %14 : f32
          %16 = arith.addf %arg11, %15 : f32
          affine.store %16, %alloca_6[%arg7, %arg8] : memref<8x128xf32>
          %17 = affine.load %0[%arg7, %arg9] : memref<8x128xf32>
          %18 = affine.load %3[%arg8, %arg9] : memref<128x128xf32>
          %19 = arith.mulf %17, %18 : f32
          %20 = arith.addf %arg10, %19 : f32
          affine.store %20, %alloca_5[%arg7, %arg8] : memref<8x128xf32>
          affine.yield %20, %16, %12 : f32, f32, f32
        }
      }
    }
    affine.for %arg7 = 0 to 8 {
      %8 = arith.index_cast %arg7 : index to i32
      %9 = arith.sitofp %8 : i32 to f32
      affine.for %arg8 = 0 to 8 {
        affine.for %arg9 = 0 to 16 step 2 {
          %10 = arith.index_cast %arg9 : index to i32
          %11 = arith.sitofp %10 : i32 to f32
          %12 = arith.negf %11 : f32
          %13 = arith.divf %12, %cst_4 : f32
          %14 = math.powf %cst_3, %13 : f32
          %15 = arith.mulf %9, %14 : f32
          %16 = math.cos %15 : f32
          %17 = math.sin %15 : f32
          %18 = affine.load %alloca_7[%arg7, %arg9 + %arg8 * 16] : memref<8x128xf32>
          %19 = affine.load %alloca_7[%arg7, %arg9 + %arg8 * 16 + 1] : memref<8x128xf32>
          %20 = arith.mulf %18, %16 : f32
          %21 = arith.mulf %19, %17 : f32
          %22 = arith.subf %20, %21 : f32
          affine.store %22, %alloca_7[%arg7, %arg9 + %arg8 * 16] : memref<8x128xf32>
          %23 = arith.mulf %18, %17 : f32
          %24 = arith.mulf %19, %16 : f32
          %25 = arith.addf %23, %24 : f32
          affine.store %25, %alloca_7[%arg7, %arg9 + %arg8 * 16 + 1] : memref<8x128xf32>
          %26 = affine.load %alloca_6[%arg7, %arg9 + %arg8 * 16] : memref<8x128xf32>
          %27 = affine.load %alloca_6[%arg7, %arg9 + %arg8 * 16 + 1] : memref<8x128xf32>
          %28 = arith.mulf %26, %16 : f32
          %29 = arith.mulf %27, %17 : f32
          %30 = arith.subf %28, %29 : f32
          affine.store %30, %alloca_6[%arg7, %arg9 + %arg8 * 16] : memref<8x128xf32>
          %31 = arith.mulf %26, %17 : f32
          %32 = arith.mulf %27, %16 : f32
          %33 = arith.addf %31, %32 : f32
          affine.store %33, %alloca_6[%arg7, %arg9 + %arg8 * 16 + 1] : memref<8x128xf32>
        }
      }
    }
    affine.for %arg7 = 0 to 8 {
      affine.for %arg8 = 0 to 8 {
        affine.for %arg9 = 0 to 8 {
          affine.store %cst_2, %alloca[%arg8, %arg9] : memref<8x8xf32>
          %8 = affine.for %arg10 = 0 to 16 iter_args(%arg11 = %cst_2) -> (f32) {
            %11 = affine.load %alloca_7[%arg8, %arg10 + %arg7 * 16] : memref<8x128xf32>
            %12 = affine.load %alloca_6[%arg9, %arg10 + %arg7 * 16] : memref<8x128xf32>
            %13 = arith.mulf %11, %12 : f32
            %14 = arith.addf %arg11, %13 : f32
            affine.store %14, %alloca[%arg8, %arg9] : memref<8x8xf32>
            affine.yield %14 : f32
          }
          %9 = affine.load %alloca[%arg8, %arg9] : memref<8x8xf32>
          %10 = arith.mulf %9, %cst_1 : f32
          affine.store %10, %alloca[%arg8, %arg9] : memref<8x8xf32>
        }
      }
      affine.for %arg8 = 0 to 8 {
        %8 = affine.load %alloca[%arg8, 0] : memref<8x8xf32>
        %9 = affine.for %arg9 = 1 to 8 iter_args(%arg10 = %8) -> (f32) {
          %11 = affine.load %alloca[%arg8, %arg9] : memref<8x8xf32>
          %12 = arith.cmpf ogt, %11, %arg10 : f32
          %13 = arith.select %12, %11, %arg10 : f32
          affine.yield %13 : f32
        }
        %10 = affine.for %arg9 = 0 to 8 iter_args(%arg10 = %cst_2) -> (f32) {
          %11 = affine.load %alloca[%arg8, %arg9] : memref<8x8xf32>
          %12 = arith.subf %11, %9 : f32
          %13 = math.exp %12 : f32
          affine.store %13, %alloca[%arg8, %arg9] : memref<8x8xf32>
          %14 = arith.addf %arg10, %13 : f32
          affine.yield %14 : f32
        }
        affine.for %arg9 = 0 to 8 {
          %11 = affine.load %alloca[%arg8, %arg9] : memref<8x8xf32>
          %12 = arith.divf %11, %10 : f32
          affine.store %12, %alloca[%arg8, %arg9] : memref<8x8xf32>
        }
      }
      affine.for %arg8 = 0 to 8 {
        affine.for %arg9 = 0 to 16 {
          %8 = affine.for %arg10 = 0 to 8 iter_args(%arg11 = %cst_2) -> (f32) {
            %9 = affine.load %alloca[%arg8, %arg10] : memref<8x8xf32>
            %10 = affine.load %alloca_5[%arg10, %arg9 + %arg7 * 16] : memref<8x128xf32>
            %11 = arith.mulf %9, %10 : f32
            %12 = arith.addf %arg11, %11 : f32
            affine.yield %12 : f32
          }
          affine.store %8, %4[%arg8, %arg9 + %arg7 * 16] : memref<8x128xf32>
        }
      }
    }
    %5 = memref.get_global @BRAM_norm_gamma : memref<128xf32>
    affine.for %arg7 = 0 to 128 {
      %8 = affine.load %arg5[%arg7] : memref<128xf32>
      affine.store %8, %5[%arg7] : memref<128xf32>
    }
    %6 = memref.get_global @BRAM_norm_beta : memref<128xf32>
    affine.for %arg7 = 0 to 128 {
      %8 = affine.load %arg6[%arg7] : memref<128xf32>
      affine.store %8, %6[%arg7] : memref<128xf32>
    }
    %7 = memref.get_global @BRAM_norm_output : memref<8x128xf32>
    affine.for %arg7 = 0 to 8 {
      %8 = affine.for %arg8 = 0 to 128 iter_args(%arg9 = %cst_2) -> (f32) {
        %13 = affine.load %4[%arg7, %arg8] : memref<8x128xf32>
        %14 = arith.addf %arg9, %13 : f32
        affine.yield %14 : f32
      }
      %9 = arith.divf %8, %cst : f32
      %10 = affine.for %arg8 = 0 to 128 iter_args(%arg9 = %cst_2) -> (f32) {
        %13 = affine.load %4[%arg7, %arg8] : memref<8x128xf32>
        %14 = arith.subf %13, %9 : f32
        %15 = arith.mulf %14, %14 : f32
        %16 = arith.addf %arg9, %15 : f32
        affine.yield %16 : f32
      }
      %11 = arith.divf %10, %cst : f32
      %12 = arith.addf %11, %cst_0 : f32
      affine.for %arg8 = 0 to 128 {
        %13 = affine.load %5[%arg8] : memref<128xf32>
        %14 = affine.load %4[%arg7, %arg8] : memref<8x128xf32>
        %15 = arith.subf %14, %9 : f32
        %16 = func.call @_ZN3hls4sqrtEf(%12) : (f32) -> f32
        %17 = arith.divf %15, %16 : f32
        %18 = arith.mulf %13, %17 : f32
        %19 = affine.load %6[%arg8] : memref<128xf32>
        %20 = arith.addf %18, %19 : f32
        affine.store %20, %7[%arg7, %arg8] : memref<8x128xf32>
      }
    }
    affine.for %arg7 = 0 to 8 {
      affine.for %arg8 = 0 to 128 {
        %8 = affine.load %7[%arg7, %arg8] : memref<8x128xf32>
        affine.store %8, %arg4[%arg7, %arg8] : memref<8x128xf32>
      }
    }
    return
  }
  func.func @_Z16load_8_128_floatPA128_fS0_(%arg0: memref<8x128xf32>, %arg1: memref<8x128xf32>) attributes {llvm.linkage = #llvm.linkage<external>} {
    affine.for %arg2 = 0 to 8 {
      affine.for %arg3 = 0 to 128 {
        %0 = affine.load %arg0[%arg2, %arg3] : memref<8x128xf32>
        affine.store %0, %arg1[%arg2, %arg3] : memref<8x128xf32>
      }
    }
    return
  }
  func.func @_Z18load_128_128_floatPA128_fS0_(%arg0: memref<128x128xf32>, %arg1: memref<128x128xf32>) attributes {llvm.linkage = #llvm.linkage<external>} {
    affine.for %arg2 = 0 to 128 {
      affine.for %arg3 = 0 to 128 {
        %0 = affine.load %arg0[%arg2, %arg3] : memref<128x128xf32>
        affine.store %0, %arg1[%arg2, %arg3] : memref<128x128xf32>
      }
    }
    return
  }
  func.func @_Z49grouped_multihead_attention_8_128_8_16_rope_floatPA128_fS0_S0_S0_S0_i(%arg0: memref<8x128xf32>, %arg1: memref<128x128xf32>, %arg2: memref<128x128xf32>, %arg3: memref<128x128xf32>, %arg4: memref<8x128xf32>, %arg5: i32) attributes {llvm.linkage = #llvm.linkage<external>} {
    %cst = arith.constant 1.600000e+01 : f32
    %cst_0 = arith.constant 1.000000e+04 : f32
    %cst_1 = arith.constant 0.000000e+00 : f32
    %cst_2 = arith.constant 2.500000e-01 : f32
    %c8_i32 = arith.constant 8 : i32
    %alloca = memref.alloca() : memref<8x8xf32>
    %alloca_3 = memref.alloca() : memref<8x128xf32>
    %alloca_4 = memref.alloca() : memref<8x128xf32>
    %alloca_5 = memref.alloca() : memref<8x128xf32>
    %0 = arith.divsi %c8_i32, %arg5 : i32
    %1 = arith.index_cast %0 : i32 to index
    affine.for %arg6 = 0 to 8 {
      affine.for %arg7 = 0 to 128 {
        affine.store %cst_1, %alloca_5[%arg6, %arg7] : memref<8x128xf32>
        affine.store %cst_1, %alloca_4[%arg6, %arg7] : memref<8x128xf32>
        affine.store %cst_1, %alloca_3[%arg6, %arg7] : memref<8x128xf32>
        %3:3 = affine.for %arg8 = 0 to 128 iter_args(%arg9 = %cst_1, %arg10 = %cst_1, %arg11 = %cst_1) -> (f32, f32, f32) {
          %4 = affine.load %arg0[%arg6, %arg8] : memref<8x128xf32>
          %5 = affine.load %arg1[%arg7, %arg8] : memref<128x128xf32>
          %6 = arith.mulf %4, %5 : f32
          %7 = arith.addf %arg11, %6 : f32
          affine.store %7, %alloca_5[%arg6, %arg7] : memref<8x128xf32>
          %8 = affine.load %arg0[%arg6, %arg8] : memref<8x128xf32>
          %9 = affine.load %arg2[%arg7, %arg8] : memref<128x128xf32>
          %10 = arith.mulf %8, %9 : f32
          %11 = arith.addf %arg10, %10 : f32
          affine.store %11, %alloca_4[%arg6, %arg7] : memref<8x128xf32>
          %12 = affine.load %arg0[%arg6, %arg8] : memref<8x128xf32>
          %13 = affine.load %arg3[%arg7, %arg8] : memref<128x128xf32>
          %14 = arith.mulf %12, %13 : f32
          %15 = arith.addf %arg9, %14 : f32
          affine.store %15, %alloca_3[%arg6, %arg7] : memref<8x128xf32>
          affine.yield %15, %11, %7 : f32, f32, f32
        }
      }
    }
    affine.for %arg6 = 0 to 8 {
      %3 = arith.index_cast %arg6 : index to i32
      %4 = arith.sitofp %3 : i32 to f32
      affine.for %arg7 = 0 to 8 {
        affine.for %arg8 = 0 to 16 step 2 {
          %5 = arith.index_cast %arg8 : index to i32
          %6 = arith.sitofp %5 : i32 to f32
          %7 = arith.negf %6 : f32
          %8 = arith.divf %7, %cst : f32
          %9 = math.powf %cst_0, %8 : f32
          %10 = arith.mulf %4, %9 : f32
          %11 = math.cos %10 : f32
          %12 = math.sin %10 : f32
          %13 = affine.load %alloca_5[%arg6, %arg8 + %arg7 * 16] : memref<8x128xf32>
          %14 = affine.load %alloca_5[%arg6, %arg8 + %arg7 * 16 + 1] : memref<8x128xf32>
          %15 = arith.mulf %13, %11 : f32
          %16 = arith.mulf %14, %12 : f32
          %17 = arith.subf %15, %16 : f32
          affine.store %17, %alloca_5[%arg6, %arg8 + %arg7 * 16] : memref<8x128xf32>
          %18 = arith.mulf %13, %12 : f32
          %19 = arith.mulf %14, %11 : f32
          %20 = arith.addf %18, %19 : f32
          affine.store %20, %alloca_5[%arg6, %arg8 + %arg7 * 16 + 1] : memref<8x128xf32>
          %21 = affine.load %alloca_4[%arg6, %arg8 + %arg7 * 16] : memref<8x128xf32>
          %22 = affine.load %alloca_4[%arg6, %arg8 + %arg7 * 16 + 1] : memref<8x128xf32>
          %23 = arith.mulf %21, %11 : f32
          %24 = arith.mulf %22, %12 : f32
          %25 = arith.subf %23, %24 : f32
          affine.store %25, %alloca_4[%arg6, %arg8 + %arg7 * 16] : memref<8x128xf32>
          %26 = arith.mulf %21, %12 : f32
          %27 = arith.mulf %22, %11 : f32
          %28 = arith.addf %26, %27 : f32
          affine.store %28, %alloca_4[%arg6, %arg8 + %arg7 * 16 + 1] : memref<8x128xf32>
        }
      }
    }
    %2 = arith.index_cast %arg5 : i32 to index
    affine.for %arg6 = 0 to %2 {
      affine.for %arg7 = 0 to %1 {
        affine.for %arg8 = 0 to 8 {
          affine.for %arg9 = 0 to 8 {
            affine.store %cst_1, %alloca[%arg8, %arg9] : memref<8x8xf32>
            %3 = affine.for %arg10 = 0 to 16 iter_args(%arg11 = %cst_1) -> (f32) {
              %6 = affine.load %alloca_5[%arg8, %arg10 + %arg7 * 16 + (%arg6 * symbol(%1)) * 16] : memref<8x128xf32>
              %7 = affine.load %alloca_4[%arg9, %arg10 + %arg7 * 16 + (%arg6 * symbol(%1)) * 16] : memref<8x128xf32>
              %8 = arith.mulf %6, %7 : f32
              %9 = arith.addf %arg11, %8 : f32
              affine.store %9, %alloca[%arg8, %arg9] : memref<8x8xf32>
              affine.yield %9 : f32
            }
            %4 = affine.load %alloca[%arg8, %arg9] : memref<8x8xf32>
            %5 = arith.mulf %4, %cst_2 : f32
            affine.store %5, %alloca[%arg8, %arg9] : memref<8x8xf32>
          }
        }
        affine.for %arg8 = 0 to 8 {
          %3 = affine.load %alloca[%arg8, 0] : memref<8x8xf32>
          %4 = affine.for %arg9 = 1 to 8 iter_args(%arg10 = %3) -> (f32) {
            %6 = affine.load %alloca[%arg8, %arg9] : memref<8x8xf32>
            %7 = arith.cmpf ogt, %6, %arg10 : f32
            %8 = arith.select %7, %6, %arg10 : f32
            affine.yield %8 : f32
          }
          %5 = affine.for %arg9 = 0 to 8 iter_args(%arg10 = %cst_1) -> (f32) {
            %6 = affine.load %alloca[%arg8, %arg9] : memref<8x8xf32>
            %7 = arith.subf %6, %4 : f32
            %8 = math.exp %7 : f32
            affine.store %8, %alloca[%arg8, %arg9] : memref<8x8xf32>
            %9 = arith.addf %arg10, %8 : f32
            affine.yield %9 : f32
          }
          affine.for %arg9 = 0 to 8 {
            %6 = affine.load %alloca[%arg8, %arg9] : memref<8x8xf32>
            %7 = arith.divf %6, %5 : f32
            affine.store %7, %alloca[%arg8, %arg9] : memref<8x8xf32>
          }
        }
        affine.for %arg8 = 0 to 8 {
          affine.for %arg9 = 0 to 16 {
            %3 = affine.for %arg10 = 0 to 8 iter_args(%arg11 = %cst_1) -> (f32) {
              %4 = affine.load %alloca[%arg8, %arg10] : memref<8x8xf32>
              %5 = affine.load %alloca_3[%arg10, %arg9 + %arg7 * 16 + (%arg6 * symbol(%1)) * 16] : memref<8x128xf32>
              %6 = arith.mulf %4, %5 : f32
              %7 = arith.addf %arg11, %6 : f32
              affine.yield %7 : f32
            }
            affine.store %3, %arg4[%arg8, %arg9 + %arg7 * 16 + (%arg6 * symbol(%1)) * 16] : memref<8x128xf32>
          }
        }
      }
    }
    return
  }
  func.func @_Z14load_128_floatPfS_(%arg0: memref<128xf32>, %arg1: memref<128xf32>) attributes {llvm.linkage = #llvm.linkage<external>} {
    affine.for %arg2 = 0 to 128 {
      %0 = affine.load %arg0[%arg2] : memref<128xf32>
      affine.store %0, %arg1[%arg2] : memref<128xf32>
    }
    return
  }
  func.func @_Z22layer_norm_8_128_floatPA128_fPfS1_S0_(%arg0: memref<8x128xf32>, %arg1: memref<128xf32>, %arg2: memref<128xf32>, %arg3: memref<8x128xf32>) attributes {llvm.linkage = #llvm.linkage<external>} {
    %cst = arith.constant 0.00999999977 : f32
    %cst_0 = arith.constant 1.280000e+02 : f32
    %cst_1 = arith.constant 0.000000e+00 : f32
    affine.for %arg4 = 0 to 8 {
      %0 = affine.for %arg5 = 0 to 128 iter_args(%arg6 = %cst_1) -> (f32) {
        %5 = affine.load %arg0[%arg4, %arg5] : memref<8x128xf32>
        %6 = arith.addf %arg6, %5 : f32
        affine.yield %6 : f32
      }
      %1 = arith.divf %0, %cst_0 : f32
      %2 = affine.for %arg5 = 0 to 128 iter_args(%arg6 = %cst_1) -> (f32) {
        %5 = affine.load %arg0[%arg4, %arg5] : memref<8x128xf32>
        %6 = arith.subf %5, %1 : f32
        %7 = arith.mulf %6, %6 : f32
        %8 = arith.addf %arg6, %7 : f32
        affine.yield %8 : f32
      }
      %3 = arith.divf %2, %cst_0 : f32
      %4 = arith.addf %3, %cst : f32
      affine.for %arg5 = 0 to 128 {
        %5 = affine.load %arg1[%arg5] : memref<128xf32>
        %6 = affine.load %arg0[%arg4, %arg5] : memref<8x128xf32>
        %7 = arith.subf %6, %1 : f32
        %8 = func.call @_ZN3hls4sqrtEf(%4) : (f32) -> f32
        %9 = arith.divf %7, %8 : f32
        %10 = arith.mulf %5, %9 : f32
        %11 = affine.load %arg2[%arg5] : memref<128xf32>
        %12 = arith.addf %10, %11 : f32
        affine.store %12, %arg3[%arg4, %arg5] : memref<8x128xf32>
      }
    }
    return
  }
  func.func @_Z17store_8_128_floatPA128_fS0_(%arg0: memref<8x128xf32>, %arg1: memref<8x128xf32>) attributes {llvm.linkage = #llvm.linkage<external>} {
    affine.for %arg2 = 0 to 8 {
      affine.for %arg3 = 0 to 128 {
        %0 = affine.load %arg0[%arg2, %arg3] : memref<8x128xf32>
        affine.store %0, %arg1[%arg2, %arg3] : memref<8x128xf32>
      }
    }
    return
  }
  func.func private @_ZN3hls4sqrtEf(f32) -> f32 attributes {llvm.linkage = #llvm.linkage<external>}
}
