#set = affine_set<(d0, d1) : (-d0 + 56 >= 0, d0 - 1 >= 0, d1 - 1 >= 0, -d1 + 56 >= 0)>
module attributes {dlti.dl_spec = #dlti.dl_spec<#dlti.dl_entry<i64, dense<64> : vector<2xi32>>, #dlti.dl_entry<f80, dense<128> : vector<2xi32>>, #dlti.dl_entry<i1, dense<8> : vector<2xi32>>, #dlti.dl_entry<!llvm.ptr, dense<64> : vector<4xi32>>, #dlti.dl_entry<i16, dense<16> : vector<2xi32>>, #dlti.dl_entry<i8, dense<8> : vector<2xi32>>, #dlti.dl_entry<i32, dense<32> : vector<2xi32>>, #dlti.dl_entry<f64, dense<64> : vector<2xi32>>, #dlti.dl_entry<f16, dense<16> : vector<2xi32>>, #dlti.dl_entry<!llvm.ptr<270>, dense<32> : vector<4xi32>>, #dlti.dl_entry<f128, dense<128> : vector<2xi32>>, #dlti.dl_entry<!llvm.ptr<272>, dense<64> : vector<4xi32>>, #dlti.dl_entry<!llvm.ptr<271>, dense<32> : vector<4xi32>>, #dlti.dl_entry<"dlti.stack_alignment", 128 : i32>, #dlti.dl_entry<"dlti.endianness", "little">>, llvm.data_layout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128", llvm.target_triple = "x86_64-unknown-linux-gnu", "polygeist.target-cpu" = "x86-64", "polygeist.target-features" = "+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87", "polygeist.tune-cpu" = "generic"} {
  memref.global @BRAM_buffer_2 : memref<16x58x58xf32> = uninitialized
  memref.global @BRAM_buffer_1 : memref<16x58x58xf32> = uninitialized
  memref.global @BRAM_batch_norm_weights : memref<4x16xf32> = uninitialized
  memref.global @BRAM_conv_bias : memref<16xf32> = uninitialized
  memref.global @BRAM_conv_weight : memref<16x16x1x1xf32> = uninitialized
  memref.global @BRAM_image_input : memref<16x56x56xf32> = uninitialized
  func.func @_Z3topPA56_A56_fPA16_A1_A1_fPfPA16_fPA58_A58_f(%arg0: memref<16x56x56xf32>, %arg1: memref<16x16x1x1xf32>, %arg2: memref<16xf32>, %arg3: memref<4x16xf32>, %arg4: memref<16x58x58xf32>) attributes {llvm.linkage = #llvm.linkage<external>} {
    %cst = arith.constant 0.000000e+00 : f32
    %cst_0 = arith.constant 9.99999974E-6 : f32
    %c0_i32 = arith.constant 0 : i32
    %c16_i32 = arith.constant 16 : i32
    %c56_i32 = arith.constant 56 : i32
    %c-1_i32 = arith.constant -1 : i32
    %0 = memref.get_global @BRAM_image_input : memref<16x56x56xf32>
    affine.for %arg5 = 0 to 16 {
      affine.for %arg6 = 0 to 56 {
        affine.for %arg7 = 0 to 56 {
          %8 = affine.load %arg0[%arg5, %arg6, %arg7] : memref<16x56x56xf32>
          affine.store %8, %0[%arg5, %arg6, %arg7] : memref<16x56x56xf32>
        }
      }
    }
    %1 = memref.get_global @BRAM_conv_weight : memref<16x16x1x1xf32>
    affine.for %arg5 = 0 to 16 {
      affine.for %arg6 = 0 to 16 {
        %8 = affine.load %arg1[%arg5, %arg6, 0, 0] : memref<16x16x1x1xf32>
        affine.store %8, %1[%arg5, %arg6, 0, 0] : memref<16x16x1x1xf32>
      }
    }
    %2 = memref.get_global @BRAM_conv_bias : memref<16xf32>
    affine.for %arg5 = 0 to 16 {
      %8 = affine.load %arg2[%arg5] : memref<16xf32>
      affine.store %8, %2[%arg5] : memref<16xf32>
    }
    %3 = memref.get_global @BRAM_batch_norm_weights : memref<4x16xf32>
    affine.for %arg5 = 0 to 4 {
      affine.for %arg6 = 0 to 16 {
        %8 = affine.load %arg3[%arg5, %arg6] : memref<4x16xf32>
        affine.store %8, %3[%arg5, %arg6] : memref<4x16xf32>
      }
    }
    %4 = memref.get_global @BRAM_buffer_1 : memref<16x58x58xf32>
    %5 = llvm.mlir.undef : i32
    affine.for %arg5 = 0 to 58 {
      affine.for %arg6 = 0 to 58 {
        affine.for %arg7 = 0 to 16 {
          %8 = affine.load %2[%arg7] : memref<16xf32>
          affine.store %8, %4[%arg7, %arg5, %arg6] : memref<16x58x58xf32>
        }
      }
    }
    %6:2 = affine.for %arg5 = 0 to 58 iter_args(%arg6 = %5, %arg7 = %5) -> (i32, i32) {
      %8 = arith.index_cast %arg5 : index to i32
      %9 = arith.addi %8, %c-1_i32 : i32
      %10 = arith.cmpi sge, %9, %c0_i32 : i32
      %11 = arith.cmpi slt, %9, %c56_i32 : i32
      %12:2 = affine.for %arg8 = 0 to 58 iter_args(%arg9 = %arg6, %arg10 = %arg7) -> (i32, i32) {
        %13 = arith.index_cast %arg8 : index to i32
        %14 = arith.addi %13, %c-1_i32 : i32
        %15 = arith.cmpi sge, %14, %c0_i32 : i32
        %16 = arith.cmpi slt, %14, %c56_i32 : i32
        %17 = arith.andi %15, %16 : i1
        %18 = arith.andi %11, %17 : i1
        %19 = arith.andi %10, %18 : i1
        %20 = arith.select %19, %c16_i32, %arg10 : i32
        %21 = affine.if #set(%arg8, %arg5) -> i32 {
          %22 = affine.for %arg11 = 0 to 16 iter_args(%arg12 = %arg9) -> (i32) {
            %23 = affine.load %0[%arg11, %arg5 - 1, %arg8 - 1] : memref<16x56x56xf32>
            affine.for %arg13 = 0 to 16 {
              %24 = affine.load %1[%arg13, %arg11, 0, 0] : memref<16x16x1x1xf32>
              %25 = arith.mulf %23, %24 : f32
              %26 = affine.load %4[%arg13, %arg5, %arg8] : memref<16x58x58xf32>
              %27 = arith.addf %26, %25 : f32
              affine.store %27, %4[%arg13, %arg5, %arg8] : memref<16x58x58xf32>
            }
            affine.yield %c16_i32 : i32
          }
          affine.yield %22 : i32
        } else {
          affine.yield %arg9 : i32
        }
        affine.yield %21, %20 : i32, i32
      }
      affine.yield %12#0, %12#1 : i32, i32
    }
    %7 = memref.get_global @BRAM_buffer_2 : memref<16x58x58xf32>
    affine.for %arg5 = 0 to 16 {
      affine.for %arg6 = 0 to 58 {
        affine.for %arg7 = 0 to 58 {
          %8 = affine.load %4[%arg5, %arg6, %arg7] : memref<16x58x58xf32>
          %9 = affine.load %3[2, %arg5] : memref<4x16xf32>
          %10 = arith.subf %8, %9 : f32
          %11 = affine.load %3[3, %arg5] : memref<4x16xf32>
          %12 = arith.addf %11, %cst_0 : f32
          %13 = func.call @_ZN3hls4sqrtEf(%12) : (f32) -> f32
          %14 = arith.divf %10, %13 : f32
          %15 = affine.load %3[0, %arg5] : memref<4x16xf32>
          %16 = arith.mulf %15, %14 : f32
          %17 = affine.load %3[1, %arg5] : memref<4x16xf32>
          %18 = arith.addf %16, %17 : f32
          affine.store %18, %7[%arg5, %arg6, %arg7] : memref<16x58x58xf32>
        }
      }
    }
    affine.for %arg5 = 0 to 16 {
      affine.for %arg6 = 0 to 58 {
        affine.for %arg7 = 0 to 58 {
          %8 = affine.load %7[%arg5, %arg6, %arg7] : memref<16x58x58xf32>
          %9 = arith.cmpf ogt, %8, %cst : f32
          %10 = arith.select %9, %8, %cst : f32
          affine.store %10, %4[%arg5, %arg6, %arg7] : memref<16x58x58xf32>
        }
      }
    }
    affine.for %arg5 = 0 to 16 {
      affine.for %arg6 = 0 to 58 {
        affine.for %arg7 = 0 to 58 {
          %8 = affine.load %4[%arg5, %arg6, %arg7] : memref<16x58x58xf32>
          affine.store %8, %arg4[%arg5, %arg6, %arg7] : memref<16x58x58xf32>
        }
      }
    }
    return
  }
  func.func @_Z19load_16_56_56_floatPA56_A56_fS1_(%arg0: memref<16x56x56xf32>, %arg1: memref<16x56x56xf32>) attributes {llvm.linkage = #llvm.linkage<external>} {
    affine.for %arg2 = 0 to 16 {
      affine.for %arg3 = 0 to 56 {
        affine.for %arg4 = 0 to 56 {
          %0 = affine.load %arg0[%arg2, %arg3, %arg4] : memref<16x56x56xf32>
          affine.store %0, %arg1[%arg2, %arg3, %arg4] : memref<16x56x56xf32>
        }
      }
    }
    return
  }
  func.func @_Z20load_16_16_1_1_floatPA16_A1_A1_fS2_(%arg0: memref<16x16x1x1xf32>, %arg1: memref<16x16x1x1xf32>) attributes {llvm.linkage = #llvm.linkage<external>} {
    affine.for %arg2 = 0 to 16 {
      affine.for %arg3 = 0 to 16 {
        %0 = affine.load %arg0[%arg2, %arg3, 0, 0] : memref<16x16x1x1xf32>
        affine.store %0, %arg1[%arg2, %arg3, 0, 0] : memref<16x16x1x1xf32>
      }
    }
    return
  }
  func.func @_Z13load_16_floatPfS_(%arg0: memref<16xf32>, %arg1: memref<16xf32>) attributes {llvm.linkage = #llvm.linkage<external>} {
    affine.for %arg2 = 0 to 16 {
      %0 = affine.load %arg0[%arg2] : memref<16xf32>
      affine.store %0, %arg1[%arg2] : memref<16xf32>
    }
    return
  }
  func.func @_Z15load_4_16_floatPA16_fS0_(%arg0: memref<4x16xf32>, %arg1: memref<4x16xf32>) attributes {llvm.linkage = #llvm.linkage<external>} {
    affine.for %arg2 = 0 to 4 {
      affine.for %arg3 = 0 to 16 {
        %0 = affine.load %arg0[%arg2, %arg3] : memref<4x16xf32>
        affine.store %0, %arg1[%arg2, %arg3] : memref<4x16xf32>
      }
    }
    return
  }
  func.func @_Z41conv2d_16_16_56_56_58_58_1_1_1_float_biasPA56_A56_fPA16_A1_A1_fPfPA58_A58_f(%arg0: memref<16x56x56xf32>, %arg1: memref<16x16x1x1xf32>, %arg2: memref<16xf32>, %arg3: memref<16x58x58xf32>) attributes {llvm.linkage = #llvm.linkage<external>} {
    %c-1_i32 = arith.constant -1 : i32
    %c56_i32 = arith.constant 56 : i32
    %c16_i32 = arith.constant 16 : i32
    %c0_i32 = arith.constant 0 : i32
    %0 = llvm.mlir.undef : i32
    affine.for %arg4 = 0 to 58 {
      affine.for %arg5 = 0 to 58 {
        affine.for %arg6 = 0 to 16 {
          %2 = affine.load %arg2[%arg6] : memref<16xf32>
          affine.store %2, %arg3[%arg6, %arg4, %arg5] : memref<16x58x58xf32>
        }
      }
    }
    %1:2 = affine.for %arg4 = 0 to 58 iter_args(%arg5 = %0, %arg6 = %0) -> (i32, i32) {
      %2 = arith.index_cast %arg4 : index to i32
      %3 = arith.addi %2, %c-1_i32 : i32
      %4 = arith.cmpi sge, %3, %c0_i32 : i32
      %5 = arith.cmpi slt, %3, %c56_i32 : i32
      %6:2 = affine.for %arg7 = 0 to 58 iter_args(%arg8 = %arg5, %arg9 = %arg6) -> (i32, i32) {
        %7 = arith.index_cast %arg7 : index to i32
        %8 = arith.addi %7, %c-1_i32 : i32
        %9 = arith.cmpi sge, %8, %c0_i32 : i32
        %10 = arith.cmpi slt, %8, %c56_i32 : i32
        %11 = arith.andi %9, %10 : i1
        %12 = arith.andi %5, %11 : i1
        %13 = arith.andi %4, %12 : i1
        %14 = arith.select %13, %c16_i32, %arg9 : i32
        %15 = affine.if #set(%arg7, %arg4) -> i32 {
          %16 = affine.for %arg10 = 0 to 16 iter_args(%arg11 = %arg8) -> (i32) {
            affine.for %arg12 = 0 to 16 {
              %17 = affine.load %arg0[%arg10, %arg4 - 1, %arg7 - 1] : memref<16x56x56xf32>
              %18 = affine.load %arg1[%arg12, %arg10, 0, 0] : memref<16x16x1x1xf32>
              %19 = arith.mulf %17, %18 : f32
              %20 = affine.load %arg3[%arg12, %arg4, %arg7] : memref<16x58x58xf32>
              %21 = arith.addf %20, %19 : f32
              affine.store %21, %arg3[%arg12, %arg4, %arg7] : memref<16x58x58xf32>
            }
            affine.yield %c16_i32 : i32
          }
          affine.yield %16 : i32
        } else {
          affine.yield %arg8 : i32
        }
        affine.yield %15, %14 : i32, i32
      }
      affine.yield %6#0, %6#1 : i32, i32
    }
    return
  }
  func.func @_Z25batch_norm_16_58_58_floatPA58_A58_fPA16_fS1_(%arg0: memref<16x58x58xf32>, %arg1: memref<4x16xf32>, %arg2: memref<16x58x58xf32>) attributes {llvm.linkage = #llvm.linkage<external>} {
    %cst = arith.constant 9.99999974E-6 : f32
    affine.for %arg3 = 0 to 16 {
      affine.for %arg4 = 0 to 58 {
        affine.for %arg5 = 0 to 58 {
          %0 = affine.load %arg0[%arg3, %arg4, %arg5] : memref<16x58x58xf32>
          %1 = affine.load %arg1[2, %arg3] : memref<4x16xf32>
          %2 = arith.subf %0, %1 : f32
          %3 = affine.load %arg1[3, %arg3] : memref<4x16xf32>
          %4 = arith.addf %3, %cst : f32
          %5 = func.call @_ZN3hls4sqrtEf(%4) : (f32) -> f32
          %6 = arith.divf %2, %5 : f32
          %7 = affine.load %arg1[0, %arg3] : memref<4x16xf32>
          %8 = arith.mulf %7, %6 : f32
          %9 = affine.load %arg1[1, %arg3] : memref<4x16xf32>
          %10 = arith.addf %8, %9 : f32
          affine.store %10, %arg2[%arg3, %arg4, %arg5] : memref<16x58x58xf32>
        }
      }
    }
    return
  }
  func.func @_Z19relu_16_58_58_floatPA58_A58_fS1_(%arg0: memref<16x58x58xf32>, %arg1: memref<16x58x58xf32>) attributes {llvm.linkage = #llvm.linkage<external>} {
    %cst = arith.constant 0.000000e+00 : f32
    affine.for %arg2 = 0 to 16 {
      affine.for %arg3 = 0 to 58 {
        affine.for %arg4 = 0 to 58 {
          %0 = affine.load %arg0[%arg2, %arg3, %arg4] : memref<16x58x58xf32>
          %1 = arith.cmpf ogt, %0, %cst : f32
          %2 = arith.select %1, %0, %cst : f32
          affine.store %2, %arg1[%arg2, %arg3, %arg4] : memref<16x58x58xf32>
        }
      }
    }
    return
  }
  func.func @_Z20store_16_58_58_floatPA58_A58_fS1_(%arg0: memref<16x58x58xf32>, %arg1: memref<16x58x58xf32>) attributes {llvm.linkage = #llvm.linkage<external>} {
    affine.for %arg2 = 0 to 16 {
      affine.for %arg3 = 0 to 58 {
        affine.for %arg4 = 0 to 58 {
          %0 = affine.load %arg0[%arg2, %arg3, %arg4] : memref<16x58x58xf32>
          affine.store %0, %arg1[%arg2, %arg3, %arg4] : memref<16x58x58xf32>
        }
      }
    }
    return
  }
  func.func private @_ZN3hls4sqrtEf(f32) -> f32 attributes {llvm.linkage = #llvm.linkage<external>}
}
