module attributes {dlti.dl_spec = #dlti.dl_spec<#dlti.dl_entry<"dlti.endianness", "little">, #dlti.dl_entry<i64, dense<64> : vector<2xi32>>, #dlti.dl_entry<f80, dense<128> : vector<2xi32>>, #dlti.dl_entry<i1, dense<8> : vector<2xi32>>, #dlti.dl_entry<i8, dense<8> : vector<2xi32>>, #dlti.dl_entry<i16, dense<16> : vector<2xi32>>, #dlti.dl_entry<i32, dense<32> : vector<2xi32>>, #dlti.dl_entry<f16, dense<16> : vector<2xi32>>, #dlti.dl_entry<f64, dense<64> : vector<2xi32>>, #dlti.dl_entry<f128, dense<128> : vector<2xi32>>>, llvm.data_layout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128", llvm.target_triple = "x86_64-unknown-linux-gnu", "polygeist.target-cpu" = "x86-64", "polygeist.target-features" = "+cx8,+fxsr,+mmx,+sse,+sse2,+x87", "polygeist.tune-cpu" = "generic"} {
  memref.global @BRAM_result : memref<1xf32> = uninitialized
  memref.global @BRAM_xAB : memref<64xf32> = uninitialized
  memref.global @BRAM_xA : memref<64xf32> = uninitialized
  memref.global @BRAM_bias : memref<1xf32> = uninitialized
  memref.global @BRAM_y : memref<64xf32> = uninitialized
  memref.global @BRAM_B : memref<64x64xf32> = uninitialized
  memref.global @BRAM_A : memref<64x64xf32> = uninitialized
  memref.global @BRAM_x : memref<64xf32> = uninitialized
  func.func @_Z3topPfPA64_fS1_S_S_S_(%arg0: memref<64xf32>, %arg1: memref<64x64xf32>, %arg2: memref<64x64xf32>, %arg3: memref<64xf32>, %arg4: memref<1xf32>, %arg5: memref<1xf32>) attributes {llvm.linkage = #llvm.linkage<external>} {
    %cst = arith.constant 0.000000e+00 : f32
    %0 = memref.get_global @BRAM_x : memref<64xf32>
    affine.for %arg6 = 0 to 64 {
      %10 = affine.load %arg0[%arg6] : memref<64xf32>
      affine.store %10, %0[%arg6] : memref<64xf32>
    }
    %1 = memref.get_global @BRAM_A : memref<64x64xf32>
    affine.for %arg6 = 0 to 64 {
      affine.for %arg7 = 0 to 64 {
        %10 = affine.load %arg1[%arg6, %arg7] : memref<64x64xf32>
        affine.store %10, %1[%arg6, %arg7] : memref<64x64xf32>
      }
    }
    %2 = memref.get_global @BRAM_B : memref<64x64xf32>
    affine.for %arg6 = 0 to 64 {
      affine.for %arg7 = 0 to 64 {
        %10 = affine.load %arg2[%arg6, %arg7] : memref<64x64xf32>
        affine.store %10, %2[%arg6, %arg7] : memref<64x64xf32>
      }
    }
    %3 = memref.get_global @BRAM_y : memref<64xf32>
    affine.for %arg6 = 0 to 64 {
      %10 = affine.load %arg3[%arg6] : memref<64xf32>
      affine.store %10, %3[%arg6] : memref<64xf32>
    }
    %4 = memref.get_global @BRAM_bias : memref<1xf32>
    %5 = affine.load %arg4[0] : memref<1xf32>
    affine.store %5, %4[0] : memref<1xf32>
    %6 = memref.get_global @BRAM_xA : memref<64xf32>
    affine.for %arg6 = 0 to 64 {
      affine.store %cst, %6[%arg6] : memref<64xf32>
    }
    affine.for %arg6 = 0 to 64 {
      %10 = affine.load %0[%arg6] : memref<64xf32>
      affine.for %arg7 = 0 to 64 {
        %11 = affine.load %1[%arg6, %arg7] : memref<64x64xf32>
        %12 = arith.mulf %11, %10 : f32
        %13 = affine.load %6[%arg7] : memref<64xf32>
        %14 = arith.addf %13, %12 : f32
        affine.store %14, %6[%arg7] : memref<64xf32>
      }
    }
    %7 = memref.get_global @BRAM_xAB : memref<64xf32>
    affine.for %arg6 = 0 to 64 {
      affine.store %cst, %7[%arg6] : memref<64xf32>
    }
    affine.for %arg6 = 0 to 64 {
      %10 = affine.load %6[%arg6] : memref<64xf32>
      affine.for %arg7 = 0 to 64 {
        %11 = affine.load %2[%arg6, %arg7] : memref<64x64xf32>
        %12 = arith.mulf %11, %10 : f32
        %13 = affine.load %7[%arg7] : memref<64xf32>
        %14 = arith.addf %13, %12 : f32
        affine.store %14, %7[%arg7] : memref<64xf32>
      }
    }
    %8 = memref.get_global @BRAM_result : memref<1xf32>
    affine.store %cst, %8[0] : memref<1xf32>
    affine.for %arg6 = 0 to 64 {
      %10 = affine.load %7[%arg6] : memref<64xf32>
      %11 = affine.load %3[%arg6] : memref<64xf32>
      %12 = arith.mulf %10, %11 : f32
      %13 = affine.load %8[0] : memref<1xf32>
      %14 = arith.addf %13, %12 : f32
      affine.store %14, %8[0] : memref<1xf32>
    }
    %9 = affine.load %8[0] : memref<1xf32>
    affine.store %9, %arg5[0] : memref<1xf32>
    return
  }
  func.func @_Z13load_64_floatPfS_(%arg0: memref<64xf32>, %arg1: memref<64xf32>) attributes {llvm.linkage = #llvm.linkage<external>} {
    affine.for %arg2 = 0 to 64 {
      %0 = affine.load %arg0[%arg2] : memref<64xf32>
      affine.store %0, %arg1[%arg2] : memref<64xf32>
    }
    return
  }
  func.func @_Z16load_64_64_floatPA64_fS0_(%arg0: memref<64x64xf32>, %arg1: memref<64x64xf32>) attributes {llvm.linkage = #llvm.linkage<external>} {
    affine.for %arg2 = 0 to 64 {
      affine.for %arg3 = 0 to 64 {
        %0 = affine.load %arg0[%arg2, %arg3] : memref<64x64xf32>
        affine.store %0, %arg1[%arg2, %arg3] : memref<64x64xf32>
      }
    }
    return
  }
  func.func @_Z12load_1_floatPfS_(%arg0: memref<1xf32>, %arg1: memref<1xf32>) attributes {llvm.linkage = #llvm.linkage<external>} {
    %0 = affine.load %arg0[0] : memref<1xf32>
    affine.store %0, %arg1[0] : memref<1xf32>
    return
  }
  func.func @_Z13store_1_floatPfS_(%arg0: memref<1xf32>, %arg1: memref<1xf32>) attributes {llvm.linkage = #llvm.linkage<external>} {
    %0 = affine.load %arg0[0] : memref<1xf32>
    affine.store %0, %arg1[0] : memref<1xf32>
    return
  }
}
